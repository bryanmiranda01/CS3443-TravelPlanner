package edu.utsa.android.settingsview;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class LogOut extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.logout);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}
