package edu.utsa.android.settingsview;



import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


import androidx.activity.ComponentActivity;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings);


        Button buttonAccount =  findViewById(R.id.account);
        buttonAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent( SettingsActivity.this, AccountSettingsActivity.class);
                startActivity(intent);
            }
        });

        Button buttonRemindersNotifs =  findViewById(R.id.remindersNotifs);
        buttonRemindersNotifs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(SettingsActivity.this, RemindersNotifications.class);
                startActivity(intent1);
            }
        });

        Button buttonlogOut = findViewById(R.id.logOut);
        buttonlogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(SettingsActivity.this, LogOut.class);
                startActivity(intent2);
            }
        });

    }



    }

